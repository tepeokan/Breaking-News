package com.okantepe.retrofit.utils

class Constants {

    companion object{
        const val BASE_URL = "https://newsapi.org/v2/"
    }
}