package com.okantepe.retrofit.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.okantepe.retrofit.R
import com.okantepe.retrofit.repository.Repository

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val repository = Repository()
        val viewModelFactory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this,viewModelFactory).get(MainViewModel::class.java)
        viewModel.getPost()
        viewModel.myResponse.observe(this, Observer { response ->
            if (response.isSuccessful) {
                //Log.d("Response", response.body()?.message!!)
                Log.d("Response", response.body()?.articles!![0].title!!)
                Log.d("Response", response.body()?.status!!)
                //Log.d("Response", response.body()?.body!!)
            }else{
                Log.d("Response1", response.errorBody().toString())
            }
        })
    }
}