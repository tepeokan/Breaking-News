package com.okantepe.retrofit.model

data class NewsModel(val status: String?, val totalResult: Int?, val articles: List<ArticlesModel>?)