package com.okantepe.retrofit.model

data class ArticlesModel(val source: Map<String?,String?>?, val author: String?, val title: String?, val description: String?, val url: String?, val urlToImage: String?, val publishedAt: String?, val content: String?)